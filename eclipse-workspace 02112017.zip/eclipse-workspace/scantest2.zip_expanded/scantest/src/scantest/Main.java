package scantest;

public class Main {

	public static void main(String[] args) {
		NetworkScan n = new NetworkScan();
		n.getNetworkIPs();

	}

}
